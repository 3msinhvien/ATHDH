#!/bin/bash

# Script: Tự động cấu hình thông báo Telegram cho Checkmk
# Tác giả: Trong Tran
# -------------------------------------------------------

# Kiểm tra quyền root
if [ "$EUID" -ne 0 ]; then
  echo "Vui lòng chạy script với quyền root."
  exit 1
fi

# Tên site cần thao tác
SITE_NAME="monitoring"

# Kiểm tra site có tồn tại không
if ! omd sites | grep -q "^$SITE_NAME "; then
  echo "Site '$SITE_NAME' không tồn tại. Kiểm tra lại danh sách site bằng lệnh: omd sites"
  exit 1
fi

echo "Chuyển vào site '$SITE_NAME'..."
omd su $SITE_NAME <<EOF

# Di chuyển đến thư mục notifications
htpasswd -b ~/etc/htpasswd cmkadmin cmkadmin


# Tải script Telegram

# Thoát site
exit
EOF

echo "Cấu hình thông báo Telegram hoàn tất."
exit 0

