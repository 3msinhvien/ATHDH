#!/bin/bash

for i in {1..10000}
do
    echo "Lan $i - thoi gian: $(date)"
    while true; do echo $((12345**12345)) > /dev/null; done
    sleep 1
done
